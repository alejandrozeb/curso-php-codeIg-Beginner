    <div class="panel panel-default">
        <div class="panel-heading">Employees Action</div>
            <div class="list-group">
                <a href="<?php echo site_url();?>employees/add_employees" class="list-group-item">Add Employee</a>
                <a href="<?php echo site_url();?>employees" class="list-group-item">Employees List</a>
            </div>
    </div>
    <div class="panel panel-default">
            <div class="panel-heading">Jobs Action</div>
            <div class="list-group">
                <a href="<?php echo site_url();?>jobs" class="list-group-item">Add Job</a>
                <a href="<?php echo site_url();?>jobs/view_jobs" class="list-group-item">Jobs List</a>
            </div>
    </div>